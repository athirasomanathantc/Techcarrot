export enum EVENTS {
    ONGOING = 'Ongoing Events',
    UPCOMING = 'Upcoming Events',
    PAST = 'Past Events'
  };

  export const TABS = ["Ongoing Events", "Upcoming Events", "Past Events"];